# Learn AI Anywhere - Marketing Assets

This folder contains all images, logos, and visual assets from the Learn AI Anywhere website, organized for easy access by the marketing team.

## Folder Structure

### 📁 logos/
**Brand and organizational logos**
- `learnAIAnywhere-logo.png` - Main Learn AI Anywhere logo
- `laia-logo.jpg` - LAIA logo (also used as favicon)
- `laia-logo-favicon.jpg` - Favicon version
- `learning-equality-logo.svg` - Learning Equality logo (SVG format)
- `youtube-logo.png` - YouTube logo
- `vite.svg` - Vite logo (development framework)

### 📁 partnership-logos/
**Partner organization logos**
- `ai-literacy-day-logo.png` - AI Literacy Day logo
- `future-upgrade-logo.png` - Future Upgrade logo
- `kiwix-logo.png` - Kiwix logo
- `learning-equality.png` - Learning Equality logo (PNG format)
- `learning-passport.jpeg` - Learning Passport logo
- `nyansapo-logo.jpg` - Nyansapo logo

### 📁 gallery-photos/
**Event and activity photos (12 images)**
- `picture-1.jpg` through `picture-12.jpg` - Gallery photos from workshops, events, and activities

### 📁 program-materials/
**Educational program materials**
- `neuropocket.jpg` - Neuropocket educational material
- `presentation-slide.jpg` - Sample presentation slide
- `worksheet.jpg` - Sample worksheet

### 📁 general-photos/
**General promotional photos**
- `classroom-workshop.png` - Classroom workshop photo
- `student-testimony.jpg` - Student testimonial photo
- `uganda-classroom.jpg` - Uganda classroom photo
- `world-map.png` - World map graphic

### 📁 videos-gifs/
**Animated content**
- `home-video.gif` - Homepage animated video/GIF (6.6 MB)

---

## Asset Summary
- **Total Assets**: 31 files
- **Logos**: 10 files
- **Partnership Logos**: 6 files
- **Gallery Photos**: 12 files
- **Program Materials**: 3 files
- **General Photos**: 4 files
- **Videos/GIFs**: 1 file

## File Formats
- **PNG**: High-quality images with transparency support
- **JPG/JPEG**: Compressed photos
- **SVG**: Scalable vector graphics (ideal for logos)
- **GIF**: Animated content

## Usage Notes
- All assets are sourced from the production website
- SVG files can be scaled to any size without quality loss
- The home-video.gif is 6.6 MB - consider compression for email attachments
- All photos are web-optimized but original quality is maintained

---

*Generated on May 22, 2026*
*Source: learn-ai-anywhere-website project*
